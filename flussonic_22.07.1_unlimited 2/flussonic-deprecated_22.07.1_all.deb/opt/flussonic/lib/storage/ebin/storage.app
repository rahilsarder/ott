{application,storage,
             [{description,"storage"},
              {vsn,"1"},
              {registered,[]},
              {applications,[kernel,stdlib,sqlite3]},
              {mod,{storage_app,[]}},
              {env,[]},
              {modules,[lua_sqlite3,storage,storage_app,storage_sup]}]}.
