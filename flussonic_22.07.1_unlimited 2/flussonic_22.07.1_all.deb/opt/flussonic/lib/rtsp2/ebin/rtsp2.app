{application,rtsp2,
             [{description,"rtsp2"},
              {vsn,"1"},
              {registered,[]},
              {applications,[kernel,stdlib,rtsp]},
              {mod,{rtsp2_app,[]}},
              {env,[]},
              {modules,[camera_discovery,rtsp2_app,rtsp2_sup,rtsp_source]}]}.
