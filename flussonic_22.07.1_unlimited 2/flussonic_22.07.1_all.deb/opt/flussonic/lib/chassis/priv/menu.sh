#!/bin/sh
a=`stty -g`
stty -icanon min 2 time 1 -echo

if [ -d _build/default/lib ]; then
  export ERL_LIBS=_build/default/lib
else
  export ERL_LIBS=/opt/flussonic/lib:/opt/flussonic/apps
fi

if [ -d /opt/flussonic/bin ]; then
  export PATH=$PATH:/opt/flussonic/bin
fi

CHASSIS_HAL=chassis_hal_simulator erl -noshell -s chassis_lcd start_demo

stty $a

