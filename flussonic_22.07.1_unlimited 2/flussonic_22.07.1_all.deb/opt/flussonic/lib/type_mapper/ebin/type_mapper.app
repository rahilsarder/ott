{application,type_mapper,
             [{description,"type_mapper"},
              {vsn,"20.09.1"},
              {registered,[]},
              {applications,[kernel,stdlib]},
              {modules,[tm_aliaser,tm_converter,tm_json,tm_logger,
                        tm_query_support,tm_validator,tm_visitor,type_mapper]},
              {env,[]}]}.
