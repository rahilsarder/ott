{application,nfs4,
             [{description,"Nfs4"},
              {vsn,"20.08.1"},
              {registered,[]},
              {applications,[stdlib,kernel]},
              {mod,{nfs4_app,[]}},
              {env,[]},
              {modules,[nfs4_app,nfs4_server,nfs4_sup,nfs4_xdr,rpc_xdr]}]}.
